insert into musica (nome, ouvintes_total, estilo, classico) values
('musica 1', 1, 'pop', true),
('musica 2', 22, 'pop', false),
('musica 3', 333, 'funk', true),
('musica 4', 4444, 'rock', true);