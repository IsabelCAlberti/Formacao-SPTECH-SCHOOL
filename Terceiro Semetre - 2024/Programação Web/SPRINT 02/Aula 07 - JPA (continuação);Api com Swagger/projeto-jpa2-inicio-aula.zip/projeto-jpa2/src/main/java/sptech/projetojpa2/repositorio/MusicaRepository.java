package sptech.projetojpa2.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;
import sptech.projetojpa2.dominio.Musica;

import java.util.List;

/*
Uma Repository centraliza os comandos de acesso a banco de dados
de uma entidade (tabela)

JpaRepository<1,2>
1 - Classe da Entidade
2 - Classe do Id (PK) da Entidade

Não é necessário criar uma implementação dessa interface.
O Spring criará uma com os comandos SQL para o banco de dados que estivermos usando
 */
public interface MusicaRepository extends JpaRepository<Musica, Integer> {

}
