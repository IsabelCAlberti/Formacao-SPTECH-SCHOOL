-- Aqui podemos ter comandos DML (insert, update e delete)
-- podem haver mais de 1 instrução.
-- Cada instrução SEMPRE deve terminar com ; (ponto e vírgula)
insert into musica
(nome, ouvintes_total, lancamento, estilo, classico)
values
('musica 1', 1, '2023-01-01', 'pop', true),
('musica 2', 22, '2022-01-01', 'pop', false),
('musica 3', 333, '2021-01-01', 'rock', true),
('musica 4', 4444, '2020-01-01', 'rock', true),
('melodia 5', 55555, '2019-01-01', 'funk', false);