-- Aqui podemos ter comando DMSL(DELETE INSERT E UPDATE) para popular o banco de dados
-- Podem haver mais de um comando por arquivo
-- O Spring Boot executa este arquivo automaticamente ao iniciar a aplicação
-- Cada instrução SEMPRE deve terminar com ponto e vírgula;


insert into musica (nome, ouvintes_total, estilo, classico) values
('musica 1', 1, 'pop',false),
('musica 2', 22, 'pop', false),
('musica 3', 333, 'funk', false),
('musica 4', 4444, 'rock', true),
('musica 5', 55555, 'country', false),
('musica 6', 666666, 'opera', true);

