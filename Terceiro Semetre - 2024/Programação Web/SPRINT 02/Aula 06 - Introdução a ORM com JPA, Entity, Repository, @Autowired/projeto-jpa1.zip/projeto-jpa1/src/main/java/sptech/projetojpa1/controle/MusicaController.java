package sptech.projetojpa1.controle;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import sptech.projetojpa1.repositorio.MusicaRepository;
import sptech.projetojpa1.dominio.Musica;

import java.util.List;

import static org.springframework.http.ResponseEntity.*;

@RestController
@RequestMapping("/musicas")
public class MusicaController {

/*
@Autowired -> Indica que é de responsabilidade do Spring em instanciar o objeto,
no caso, o 'repository'.
Assim, quando qualquer dos método da classe precisar do 'repository', ele já terá um valor válido
 */
    @Autowired
    private MusicaRepository repository;

    @GetMapping
    public ResponseEntity<List<Musica>> get() {
        // findAll() -> equivale a um "select * from tabela"
        var lista = repository.findAll();
//        List<Musica> lista = repository.findAll();
        return lista.isEmpty()
                ? status(204).build()
                : status(200).body(lista);
    }

    @PostMapping
    public ResponseEntity<Musica> post(@RequestBody Musica novaMusica) {
        // save() -> equivale a um "insert into tabela" ou a um "update tabela". Se o campo que for a Id será um insert, caso contrário, um update
        repository.save(novaMusica);
        return status(201).body(novaMusica);
    }

    @GetMapping("/{codigo}")
    public ResponseEntity<Musica> get(@PathVariable Integer codigo) {
        /*
ResponseEntity.of() -> retorna, automaticamente:
404 e sem corpo, se seu argumento não tiver valor
200 e com corpo, se seu argumento tiver valor, que será o corpo da resposta
         */
        return ResponseEntity.of(repository.findById(codigo));
        // return of(repository.findById(codigo));
    }

    @DeleteMapping("/{codigo}")
    public ResponseEntity<Void> delete(@PathVariable Integer codigo) {
        // existsById() -> retorna true se o valor é uma PK que existe para a entidade
        if (repository.existsById(codigo)) {
            // deleteById() -> equivale a um "delete from tabela where id = ?"
            repository.deleteById(codigo);
            return status(204).build();
        }
        return status(404).build();
    }

    @PutMapping("/{codigo}")
    public ResponseEntity<Musica> put(@PathVariable Integer codigo,
                      @RequestBody Musica musica) {
        if (repository.existsById(codigo)) {
            musica.setCodigo(codigo);
            repository.save(musica);
            return status(200).body(musica);
        }

        return status(404).build();
    }
}


