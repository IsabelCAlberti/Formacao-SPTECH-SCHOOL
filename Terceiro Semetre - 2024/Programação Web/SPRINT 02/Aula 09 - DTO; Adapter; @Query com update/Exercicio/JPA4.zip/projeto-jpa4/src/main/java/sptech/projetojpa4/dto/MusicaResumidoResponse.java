package sptech.projetojpa4.dto;

import sptech.projetojpa4.dominio.Musica;

public class MusicaResumidoResponse {
    private Integer codigo;
    private String nome;
    private String compositor;

    public MusicaResumidoResponse(Musica musica) {
        this.codigo = musica.getCodigo();
        this.nome = musica.getNome();
        this.compositor = musica.getCompositor().getNome();
    }

    public Integer getCodigo() {
        return codigo;
    }

    public String getNome() {
        return nome;
    }

    public String getCompositor() {
        return compositor;
    }
}
