package sptech.projetojpa4.dto;

import sptech.projetojpa4.dominio.Musica;
/*
Essa classe implementa 2 padrões de projeto
DTO- Data Transfer Object. Serve para transportar dados apenas
Adapter - Ela "trnasforma", "adapta" um objeto em outro
 */
public class MusicaSimplesResponse {
    private Integer codigo;
    private String nome;

    /*
    O padrão adapter foi implementado no construtor
     */
    public MusicaSimplesResponse(Musica musica) {
        this.codigo = musica.getCodigo();
        this.nome = musica.getNome();
    }

    public Integer getCodigo() {
        return codigo;
    }

    public String getNome() {
        return nome;
    }
}
