package sptech.projetojpa4.controle;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import sptech.projetojpa4.dto.CompositorRelatorioResponse;
import sptech.projetojpa4.dto.CompositorSimplesResponse;
import sptech.projetojpa4.repositorio.MusicaRepository;

import java.util.List;

import static org.springframework.http.ResponseEntity.status;

@RestController
@RequestMapping("/compositores")
public class CompositorController {
    @Autowired
    private MusicaRepository repository;

    @GetMapping("/simples")
    public ResponseEntity<List<CompositorSimplesResponse>> getCompositorSimples(){
        return status(200).body(repository.findCompositorSimples());
    }
    @GetMapping("/relatorio")
    public ResponseEntity<CompositorRelatorioResponse> getCompositorRelatorio(){
        return status(200).body(new CompositorRelatorioResponse(repository.countCompositor()));
    }

}
