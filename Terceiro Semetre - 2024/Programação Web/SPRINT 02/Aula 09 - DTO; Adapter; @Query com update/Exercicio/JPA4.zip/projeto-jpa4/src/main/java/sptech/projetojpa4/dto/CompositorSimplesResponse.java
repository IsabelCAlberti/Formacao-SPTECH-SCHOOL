package sptech.projetojpa4.dto;

import sptech.projetojpa4.dominio.Compositor;

public class CompositorSimplesResponse {
    private Integer codigo;
    private String apelido;

    public CompositorSimplesResponse(Compositor compositor) {
        this.codigo = compositor.getCodigo();
        this.apelido = compositor.getApelido();
    }

    public Integer getCodigo() {
        return codigo;
    }

    public String getApelido() {
        return apelido;
    }
}
