package sptech.projetojpa4.dto;

import sptech.projetojpa4.dominio.Compositor;

import java.util.List;

public class CompositorRelatorioResponse {
    private Integer totalOuvintes;

    public CompositorRelatorioResponse(Integer totalOuvintes) {
        this.totalOuvintes = totalOuvintes;
    }

    public Integer getTotalOuvintes() {
        return totalOuvintes;
    }
}
