package sptech.projetojpa2.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import sptech.projetojpa2.dominio.Compositor;
import sptech.projetojpa2.dominio.Musica;

import java.util.List;


public interface CompositorRepository extends
        JpaRepository<Compositor, Integer> {
    List<Compositor> findByNome(String nome);
    List<Compositor> findByApelido(String apelido);

    @Query("select c.documento from Compositor c where c.codigo = ?1")
    byte[] findFotoByCodigo(Integer id);
}
