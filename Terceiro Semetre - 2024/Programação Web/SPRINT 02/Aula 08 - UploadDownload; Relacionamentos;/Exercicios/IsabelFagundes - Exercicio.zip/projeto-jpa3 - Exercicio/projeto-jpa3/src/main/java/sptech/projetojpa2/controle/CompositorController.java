package sptech.projetojpa2.controle;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import sptech.projetojpa2.repositorio.CompositorRepository;
import sptech.projetojpa2.repositorio.MusicaRepository;

@RestController
@RequestMapping("/compositores")
public class CompositorController {


    @Autowired
    private CompositorRepository repository;

    //Crie um Endpoint GET /compositores/documento/{codigo} que retorna o conteúdo do documento do compositor
    // indicado pelo 'codigo'. Indique o tipo certo de arquivo na documentação.
    @GetMapping(value = "/documento/{codigo}", produces = "text/csv")
    public ResponseEntity<byte[]> getDocumento(@PathVariable Integer codigo) {
        var documento = repository.findById(codigo).get();
        return ResponseEntity.ok(documento.getDocumento());
    }

    @PatchMapping(value = "/documento/{codigo}", consumes = "text/csv")
    public ResponseEntity<?> patchDocumento(@PathVariable Integer codigo, @RequestBody byte[] documento) {
        var compositor = repository.findById(codigo).get();
        compositor.setDocumento(documento);
        repository.save(compositor);
        return ResponseEntity.ok().build();
    }
}