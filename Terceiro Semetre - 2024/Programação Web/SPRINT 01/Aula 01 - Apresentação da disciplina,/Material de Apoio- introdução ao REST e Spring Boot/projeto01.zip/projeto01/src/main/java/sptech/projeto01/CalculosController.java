package sptech.projeto01;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/calculos")
public class CalculosController {
/*
Neste caso a URI contém um PATH PARAM ({numero})
Ela foi associada automaticamente ao parâmetro "numero" porque...
1. Ele está anotado com @PathVariable
2. Seu nome é o mesmo "numero"
 */
    @GetMapping("/dobro/{numero}") // ex: /calculos/dobro/15
    public String dobro(@PathVariable Double numero) {
        return "O dobro de %s é %s".formatted(numero, numero * 2);
    }

    /*
EndPoint -> /calculos/media/{num1}/{num2}
Retorna: "A média entre 6.0 e 8.0 é 7.0"
*/
    @GetMapping("/media/{num1}/{num2}")
    public String media(@PathVariable Double num1,
                        @PathVariable Double num2) {
        return "A média entre %s e %s é %.2f"
                .formatted(num1, num2, (num1+num2)/2);
    }

    /*
EndPoint -> /calculos/resultado/{nota1}/{nota2}
Retorna: "Parabéns! Aprovado!" (caso a média entre as notas for >= 6)
         OU
         "Tente outra vez!" (caso a média entre as notas for < 6)
     */
    @GetMapping("/resultado/{nota1}/{nota2}")
    public String resultado(@PathVariable Double nota1,
                            @PathVariable Double nota2) {
        var media = (nota1 + nota2) / 2;

        return media >= 6
                ? "Parabéns! Aprovado"
                : "Tente outra vez";
    }
}

