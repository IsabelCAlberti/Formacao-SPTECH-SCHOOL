package sptech.projeto01;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/*
@RestController -> Isso é uma Anotação (Annotation).
São uma forma de implementar Meta-Programação
No caso desta anotação, ela indica que a classe será uma
Controller REST. Ou seja, poderá ter EndPoints (chamadas)
 */
@RestController
@RequestMapping("/frases") // indica que todos os EndPoint serão "/frases/???"
public class FrasesController {

    /*
@GetMapping -> Transforma o método em um EndPoint (ou Chamada ou "Rota")
O valor dentro dele será concatenado com o valor em @RequestMapping
Por isso este aqui será chamado por /frases/cumprimentar

http://localhost:8080/frases/palmeiras-tem-mundial
É uma URL ou Endereço

Só a parte "/frases/cumprimentar" chamados de URI

A convenção para URIs é kebab-case (ou hifen-case ou css-case)
     */
    @GetMapping("/cumprimentar") // localhost:8080/frases/cumprimentar
    public String cumprimentar() {
        return "Sejam bem vindos à minha API";
    }

    /*
Endpoint: /frases/boa-noite que retorna uma frase de boa noite
     */
    @GetMapping("/boa-noite") // localhost:8080/frases/boa-noite
    public String boaNoite() {
        return "Durma bem! Boa noite!";
    }

    @GetMapping("/populacao-mundial")
    public Long populacao() {
        return 8_000_000_000L;
    }

    @GetMapping("/palmeiras-tem-mundial")
    public Boolean temMundial() {
        return false;
    }
}



