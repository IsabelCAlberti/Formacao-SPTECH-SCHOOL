package sptech.projeto01;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

/*
Toda Rest Controller é um SINGLETON
Ou seja será criada somente 1 (uma) instância dela na aplicação
 */
@RestController
@RequestMapping("/paises")
public class PaisesController {

    private int acessos = 0;

    private List<String> paises = new ArrayList<>(
                                  List.of("Chile", "México", "Cuba", "Perú"));

    @GetMapping("/acessos")
    public int acessos() {
        acessos++;
        return acessos;
    }

    // EndPoint: /paises/{posicao} -> retorna o pais na "posicao" na lista
    // ex: /paises/1  -> retorna "México"

    @GetMapping("/{posicao}")
    public String getPais(@PathVariable int posicao) {
        return paises.get(posicao);
    }

    // EndPoint: /paises/novo/{nome} -> insere o "nome" na lista e
    // retorna a frase "País NOME inserido com sucesso"
    // Dica: chame o outro endpoint para testar se foi adicionado mesmo
    @GetMapping("/novo/{nome}")
    public String getPais(@PathVariable String nome) {
        paises.add(nome);
        return "País %s inserido com sucesso".formatted(nome);
    }
}
