package com.sptech.projeto04;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Projeto04Application {

	public static void main(String[] args) {
		SpringApplication.run(Projeto04Application.class, args);
	}

}
