package sptech.projeto04;

import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import org.hibernate.validator.constraints.br.CPF;
import org.hibernate.validator.constraints.br.TituloEleitoral;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class Pokemon {

    /*
@NotBlank -> Rejeita: null, "", ou "    " (aspas só com espaços)
É a melhor opção de validação para texto (String)
NÃO DEVEMOS usar em outros tipos (Double, Boolean etc)
     */
    @NotBlank
    @Size(min = 2, max = 10)
    private String nome;

    /*
@NotNull -> Rejeita null (valor literal null ou campo não enviado)
     */
    @NotNull
    @Valid // se tivermos um objeto de tipo "complexo", precisamos dela
    private TipoPokemon tipo;

    /*
    Podemos COMBINAR anotações de validação
     */
    @NotNull
    @DecimalMin("0.1") // @Min("1") p/ inteiros
    @DecimalMax("10000.0") //@Max("100") p/ inteiros
//    @Positive
//    @PositiveOrZero
//    @Negative
//    @NegativeOrZero
    private Double forca;

    private boolean solto;

    private LocalDateTime criacao = LocalDateTime.now();

    @Email
    private String email;

    @CPF
    private String cpf;

    @TituloEleitoral
    private String tituloEleitor;

    @Past
//    @PastOrPresent
    private LocalDate nascimento;

    @Future
//    @FutureOrPresent
    private LocalDate viveAte;


    /*
    Esta anotação valida usando Expressões Regulares (Regex)
     */
    @Pattern(regexp = "(\\(?\\d{2}\\)?\\s)?(\\d{4,5}\\-\\d{4})")
    private String telefone;

    public String getEmail() {
        return email;
    }

    public String getCpf() {
        return cpf;
    }

    public String getTituloEleitor() {
        return tituloEleitor;
    }

    public LocalDate getNascimento() {
        return nascimento;
    }

    public LocalDate getViveAte() {
        return viveAte;
    }

    public String getTelefone() {
        return telefone;
    }

    public String getNome() {
        return nome;
    }

    public TipoPokemon getTipo() {
        return tipo;
    }

    public Double getForca() {
        return forca;
    }

    public boolean isSolto() {
        return solto;
    }

    public LocalDateTime getCriacao() {
        return criacao;
    }
}
