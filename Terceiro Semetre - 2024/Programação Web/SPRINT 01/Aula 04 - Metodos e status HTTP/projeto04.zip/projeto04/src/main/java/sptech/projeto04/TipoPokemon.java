package sptech.projeto04;

import jakarta.validation.constraints.NotBlank;

public class TipoPokemon {

    @NotBlank
    private String codigo; // mnemonico: "aq", "el", "fo"

    @NotBlank
    private String nome; // "aquático", "elétrico", "fogo"

    public String getCodigo() {
        return codigo;
    }

    public String getNome() {
        return nome;
    }
}
