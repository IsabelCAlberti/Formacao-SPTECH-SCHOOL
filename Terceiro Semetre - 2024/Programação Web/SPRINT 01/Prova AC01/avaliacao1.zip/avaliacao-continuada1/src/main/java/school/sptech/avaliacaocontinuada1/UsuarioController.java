package school.sptech.avaliacaocontinuada1;

public class UsuarioController {

}
