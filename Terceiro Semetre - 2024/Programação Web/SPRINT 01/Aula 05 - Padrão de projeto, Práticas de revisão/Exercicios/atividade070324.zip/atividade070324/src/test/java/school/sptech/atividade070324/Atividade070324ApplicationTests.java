package school.sptech.atividade070324;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Atividade070324ApplicationTests {

	@Test
	void contextLoads() {
	}

}
