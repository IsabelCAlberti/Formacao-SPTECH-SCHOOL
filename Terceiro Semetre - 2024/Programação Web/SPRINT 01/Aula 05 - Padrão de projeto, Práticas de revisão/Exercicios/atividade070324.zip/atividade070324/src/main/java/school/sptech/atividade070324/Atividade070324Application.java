package school.sptech.atividade070324;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Atividade070324Application {

	public static void main(String[] args) {
		SpringApplication.run(Atividade070324Application.class, args);
	}

}
