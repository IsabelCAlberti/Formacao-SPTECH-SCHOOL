package sptech.projetocarros;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoCarrosApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoCarrosApplication.class, args);
	}

}
