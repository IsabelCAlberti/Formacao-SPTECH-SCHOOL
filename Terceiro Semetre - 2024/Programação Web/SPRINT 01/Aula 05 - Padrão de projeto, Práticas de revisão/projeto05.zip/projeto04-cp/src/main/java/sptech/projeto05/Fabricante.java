package sptech.projeto05;

public class Fabricante {

    private String codigo;

    private String nome;

    private boolean nacional;

    public String getCodigo() {
        return codigo;
    }

    public String getNome() {
        return nome;
    }

    public boolean isNacional() {
        return nacional;
    }
}
